package skeleton;


public class Character {

	static String name = "Champion";
	static int health;
	static int mana;				//Casters only
	static int stamina;   			//Fighters only
	static int focus;				//Archers only
	static int gold;
	static int xp;
	static int level;
	static String secondBar;		//Defines mana/stamina/focus
	static int usable;				//0 stamina, 1 mana, 2 focus
	
	static int strength;			//Modifies melee attack damage
	static int endurance;  			//For warriors: modifies stamina
	static int intelligence;		//Modifies spell attack damage
	static int wisdom;				//For mages: modifies mana
	static int dexterity;			//Modifies ranged attack damage
	static int concentration;		//For rogues: modifies focus
	
	static int charisma;			//Affects interaction with NPCs
	static int intimidation;		//Affects interaction with NPCs
	
	static int race;
	/*
	0 = Orc
	1 = Human
	2 = Elf 
	*/
	
	static int gender;
	/*
	0 = Male
	1 = Female
	*/
	
	static int role;
	/*
	0 = Fighter
	1 = Caster
	2 = Archer
	*/
	
	static int question1;
	/*
	0 = -5 strength
	1 = no change to strength
	2 = +5 strength
	*/
	
	static int question2;
	/*
	0 = +5 intelligence
	1 = -5 intelligence
	2 = no change to intelligence 
	*/
	
	static int question3;
	/*
	0 = +5 dexterity
	1 = no change to dexterity
	2 = -5 dexterity
	*/
	
	public static void CharacterCreate(int ccRace, int ccGender, int ccRole, int qq1, int qq2, int qq3) {
		
		if (ccRace == 0 && ccGender == 0 && ccRole == 0) {
			health = 150;
			secondBar = "Stamina";
			stamina = 100;
			strength = 30;
			intelligence = 15;
			dexterity = 15;
			charisma = 0;
			intimidation = 30;
		}
		else if (ccRace == 0 && ccGender == 0 && ccRole == 1) {
			health = 100;
			secondBar = "Mana";
			mana = 50;
			strength = 20;
			intelligence = 20;
			dexterity = 20;
			charisma = 0;
			intimidation = 30;	
		}
		
		else if (ccRace == 0 && ccGender == 0 && ccRole == 2) {
			health = 125;
			secondBar = "Focus";
			focus = 75;
			strength = 20;
			intelligence = 15;
			dexterity = 25;
			charisma = 0;
			intimidation = 30;
		}
		
		else if (ccRace == 0 && ccGender == 1 && ccRole == 0) {
			health = 125;
			secondBar = "Stamina";
			stamina = 75;
			strength = 25;
			intelligence = 15;
			dexterity = 20;
			charisma = 5;
			intimidation = 25;
		}
		
		else if (ccRace == 0 && ccGender == 1 && ccRole == 1) {
			health = 75;
			secondBar = "Mana";
			mana = 50;
			strength = 20;
			intelligence = 20;
			dexterity = 20;
			charisma = 5;
			intimidation = 25;
		}
		
		else if (ccRace == 0 && ccGender == 1 && ccRole == 2) {
			health = 100;
			secondBar = "Focus";
			focus = 75;
			strength = 20;
			intelligence = 15;
			dexterity = 25;
			charisma = 5;
			intimidation = 25;
		}
		
		else if (ccRace == 1 && ccGender == 0 && ccRole == 0) {
			health = 100;
			secondBar = "Stamina";
			stamina = 75;
			strength = 25;
			intelligence = 20;
			dexterity = 15;
			charisma = 10;
			intimidation = 20;
		}
		else if (ccRace == 1 && ccGender == 0 && ccRole == 1) {
			health = 60;
			secondBar = "Mana";
			mana = 100;
			strength = 20;
			intelligence = 30;
			dexterity = 15;
			charisma = 10;
			intimidation = 20;	
		}
		
		else if (ccRace == 1 && ccGender == 0 && ccRole == 2) {
			health = 80;
			secondBar = "Focus";
			focus = 75;
			strength = 20;
			intelligence = 20;
			dexterity = 20;
			charisma = 10;
			intimidation = 20;
		}
		
		else if (ccRace == 1 && ccGender == 1 && ccRole == 0) {
			health = 80;
			secondBar = "Stamina";
			stamina = 50;
			strength = 25;
			intelligence = 20;
			dexterity = 15;
			charisma = 15;
			intimidation = 15;
		}
		
		else if (ccRace == 1 && ccGender == 1 && ccRole == 1) {
			health = 60;
			secondBar = "Mana";
			mana = 75;
			strength = 20;
			intelligence = 25;
			dexterity = 15;
			charisma = 15;
			intimidation = 15;
		}
		
		else if (ccRace == 1 && ccGender == 1 && ccRole == 2) {
			health = 60;
			secondBar = "Focus";
			focus = 60;
			strength = 20;
			intelligence = 20;
			dexterity = 20;
			charisma = 15;
			intimidation = 15;
		}
		
		else if (ccRace == 2 && ccGender == 0 && ccRole == 0) {
			health = 80;
			secondBar = "Stamina";
			stamina = 50;
			strength = 20;
			intelligence = 20;
			dexterity = 20;
			charisma = 20;
			intimidation = 10;
		}
		else if (ccRace == 2 && ccGender == 0 && ccRole == 1) {
			health = 60;
			secondBar = "Mana";
			mana = 50;
			strength = 15;
			intelligence = 20;
			dexterity = 20;
			charisma = 20;
			intimidation = 10;	
		}
		
		else if (ccRace == 2 && ccGender == 0 && ccRole == 2) {
			health = 100;
			secondBar = "Focus";
			focus = 75;
			strength = 15;
			intelligence = 20;
			dexterity = 30;
			charisma = 20;
			intimidation = 10;
		}
		
		else if (ccRace == 2 && ccGender == 1 && ccRole == 0) {
			health = 80;
			secondBar = "Stamina";
			stamina = 40;
			strength = 20;
			intelligence = 20;
			dexterity = 20;
			charisma = 25;
			intimidation = 5;
		}
		
		else if (ccRace == 2 && ccGender == 1 && ccRole == 1) {
			health = 40;
			secondBar = "Mana";
			mana = 60;
			strength = 15;
			intelligence = 25;
			dexterity = 20;
			charisma = 25;
			intimidation = 5;
		}
		
		else if (ccRace == 2 && ccGender == 1 && ccRole == 2) {
			health = 80;
			secondBar = "Focus";
			focus = 60;
			strength = 15;
			intelligence = 20;
			dexterity = 30;
			charisma = 25;
			intimidation = 5;
		}	
		
		else if (qq1 == 0) {
			strength -= 5;
		}
		
		else if (qq1 == 2) {
			strength += 5;
		}
		
		else if (qq2 == 0) {
			intelligence += 5;
		}
		
		else if (qq2 == 1) {
			intelligence -= 5;
		}
		
		else if (qq3 == 1) {
			dexterity += 5;
		}

		else if (qq3 == 2) {
			dexterity -= 5;
		}

	}
	
	public static int secondBarSet(String bar) {
		if (bar == "Stamina") {
			usable = stamina;
			
		}

		else if (bar == "Mana") {
			usable = mana;
			
		}
		
		else if (bar == "Focus") {
			usable = focus;
			
		}
		
		return usable;
	}	
}
