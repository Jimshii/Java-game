package skeleton;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.EtchedBorder;

public class Example extends JFrame {


	private static final long serialVersionUID = 1L;
	protected Component main;

	public Example() {
        initUI();
    }

    public final void initUI() {

    	final JPanel main = new JPanel(new BorderLayout());
        main.setBackground(Color.gray);
        main.setLayout(new BoxLayout(main, BoxLayout.X_AXIS));
        main.setBorder(BorderFactory.createEmptyBorder(0, 10, 10, 10));

        
        getContentPane().add(main);
    
        final JLabel statusbar = new JLabel("Status");
        statusbar.setBorder(BorderFactory.createEtchedBorder(
                EtchedBorder.RAISED));
        
        add(statusbar, BorderLayout.SOUTH);

        final JMenuBar menubar = new JMenuBar();

        JMenu game = new JMenu("Game");
        JMenu settings = new JMenu("Settings");
        JMenu help = new JMenu("Help");
        
        final JMenu cstuff = new JMenu("");
        cstuff.setVisible(true);
        
        final JMenuItem CharFull = new JMenuItem("");
        KeyStroke ctrlC = KeyStroke.getKeyStroke(KeyEvent.VK_C,
        InputEvent.CTRL_MASK);
        CharFull.setAccelerator(ctrlC);
        CharFull.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
            	statusbar.setText("Character");
            }
        });
        
        final JMenuItem SkillsFull = new JMenuItem("");
        KeyStroke ctrlS = KeyStroke.getKeyStroke(KeyEvent.VK_S,
        InputEvent.CTRL_MASK);
        SkillsFull.setAccelerator(ctrlS);
        SkillsFull.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
            	statusbar.setText("Skills");
            }
        });
        
        final JMenuItem JournalFull = new JMenuItem("");
        KeyStroke ctrlJ = KeyStroke.getKeyStroke(KeyEvent.VK_J,
        InputEvent.CTRL_MASK);
        JournalFull.setAccelerator(ctrlJ);
        JournalFull.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
            	statusbar.setText("Journal");
            }
        });
        
        final JMenuItem InvFull = new JMenuItem("");
        KeyStroke ctrlI = KeyStroke.getKeyStroke(KeyEvent.VK_I,
        InputEvent.CTRL_MASK);
        InvFull.setAccelerator(ctrlI);
        InvFull.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
            	statusbar.setText("Inventory");
            }
        });
        
        JMenuItem Exit = new JMenuItem("Exit");
        Exit.setToolTipText("Exit application");
        Exit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
            	statusbar.setText("Exiting");
            	int yesNo = JOptionPane.showConfirmDialog(main, "Are you sure you want to exit?",
                        "Exiting", JOptionPane.YES_NO_OPTION);
            	if (yesNo == 0) {
            		System.exit(0);
            	}
            	else {
            		statusbar.setText("Status");
            	}
            }
        });
        
        
        
        JMenu Vset = new JMenu("Visual Settings");
        Vset.setToolTipText("Settings related to viewing the game");
        Vset.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
            	statusbar.setText("Visual Settings");
            }

        });
        
        JMenu Aset = new JMenu("Audio Settings");
        Aset.setToolTipText("Settings related to sound");
        Aset.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
            	statusbar.setText("Audio Settings");
            }
        });
        
        JMenu Gset = new JMenu("Game Settings");
        Gset.setToolTipText("Overall game settings");
        Gset.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
            	statusbar.setText("Game Settings");
            }

        });
        
        JMenuItem Controls = new JMenuItem("Controls");
        Controls.setToolTipText("Opens a text file with game controls");
        Controls.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
            	statusbar.setText("Opening controls...");
                JOptionPane.showMessageDialog(main, "Can't have controls for a game that doesn't exist!", 
                		"Controls", JOptionPane.INFORMATION_MESSAGE);
                }

        });
        
        ImageIcon dungeon = new ImageIcon("images/dungeon.jpg");
        ImageIcon dungeonPressed = new ImageIcon("images/dungeon2.png");
        final JButton dungeonButton = new JButton(dungeon);
        dungeonButton.setBorder(null);
        dungeonButton.setPressedIcon(dungeonPressed);
        dungeonButton.setBackground(Color.gray);
        dungeonButton.setToolTipText("Enter a random dungeon");
        dungeonButton.setPreferredSize(new Dimension(149, 149));
        dungeonButton.setOpaque(false);
        dungeonButton.setContentAreaFilled(false);
        
        ImageIcon shop = new ImageIcon("images/shop.jpg");
        ImageIcon shopPressed = new ImageIcon("images/shop.png");
        final JButton shopButton = new JButton(shop);
        shopButton.setPressedIcon(shopPressed);
        shopButton.setBackground(Color.gray);
        shopButton.setBorder(null);
        shopButton.setToolTipText("Visit the shop");
        shopButton.setPreferredSize(new Dimension(149, 149));
        shopButton.setOpaque(false);
        shopButton.setContentAreaFilled(false);

		final JLabel chInfo = new JLabel("");
        final Border empty = new EmptyBorder(5, 5, 5, 5);
        final Border raisedbevel = BorderFactory.createRaisedBevelBorder();
        chInfo.setBorder(new CompoundBorder(raisedbevel, empty));
        chInfo.setMaximumSize(new Dimension(200, 550));
        chInfo.setOpaque(true);
        
        final Object[] races = {"Grocimo (Orc)",
        		"Bladefell (Human)",
        		"Antiva (Elf)"
        };
        
        final Object[] genders = {"Yes (Male)",
        		"Um actually... (Female)"
        };
        
        final Object[] roles = {"I'm a fighter (Warrior)",
        		"I'm a caster (Mage)",
        		"I'm an archer (Rogue)"
        };
        
        final Object[] q1 = {"Nah",
        		"Occasionally. It's not a habit though",
        		"HELL YEAH ALL DAY"
        };
        
        final Object[] q2 = {"The egg",
        		"The chicken",
        		"Why does this matter?"
        };
        
        final Object[] q3 = {"Definitely",
        		"Brawn over speed any day",
        		"They are both viable"
        };
        
        
        JMenuItem New = new JMenuItem("New Game");
        New.setToolTipText("Begins a new game");
        New.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent event) {
        		main.removeAll();
        		statusbar.setText("Starting a new game"); 
                Character.name = JOptionPane.showInputDialog(main, "What is your name, weary traveller?",
                        "Character Name", JOptionPane.DEFAULT_OPTION);
                main.add(Box.createHorizontalGlue());
                main.add(chInfo);
                main.add(Box.createRigidArea(new Dimension(375, 0)));
                main.add(dungeonButton);
                main.add(Box.createRigidArea(new Dimension(15, 0)));
                main.add(shopButton);
                main.add(Box.createRigidArea(new Dimension(400, 0)));
                Character.race = JOptionPane.showOptionDialog(
                		null, "Tell me, where are you from?",
                	    "Race",
                	    JOptionPane.YES_NO_CANCEL_OPTION,
                	    JOptionPane.PLAIN_MESSAGE, null,
                	    races,
                	    races[2]);
                Character.gender = JOptionPane.showOptionDialog(
                		null, "So you're a boy, right? I couldn't invade your privacy and check myself.",
                		"Gender",
                		JOptionPane.YES_NO_CANCEL_OPTION,
                		JOptionPane.PLAIN_MESSAGE, null,
                		genders,
                		genders[1]);
                Character.role = JOptionPane.showOptionDialog(
                		null, "You're pretty beaten up. Is it from battling the Boyehou? What role do you play in battles?",
                		"Role",
                		JOptionPane.YES_NO_CANCEL_OPTION,
                		JOptionPane.PLAIN_MESSAGE, null,
                		roles,
                		roles[2]);
                Character.question1 = JOptionPane.showOptionDialog(
                		null, "You seem pretty defined. Do you exercise often?",
                		"Question One",
                		JOptionPane.YES_NO_CANCEL_OPTION,
                		JOptionPane.PLAIN_MESSAGE, null,
                		q1,
                		q1[2]);
                Character.question2 = JOptionPane.showOptionDialog(
                		null, "And I'm curious, which came first, the chicken or the egg?",
                		"Question Two",
                		JOptionPane.YES_NO_CANCEL_OPTION,
                		JOptionPane.PLAIN_MESSAGE, null,
                		q2,
                		q2[2]);
                Character.question3 = JOptionPane.showOptionDialog(
                		null, "Oh! Do you agree with the statement 'A quick rogue can beat a strong warrior with ease'?",
                		"Question Three",
                		JOptionPane.YES_NO_CANCEL_OPTION,
                		JOptionPane.PLAIN_MESSAGE, null,
                		q3,
                		q3[2]);
                Character.CharacterCreate(Character.race, Character.gender, Character.role, 
                		Character.question1, Character.question2, Character.question3);
                int Use = Character.secondBarSet(Character.secondBar);
                chInfo.setText("<html><i><FONT COLOR=GREEN>" + Character.name + "</FONT></i><br><br><FONT COLOR=#B8860B>Level: </FONT>" + 
        				Character.level + "<br><FONT COLOR=#9932CC>XP:</FONT> " + Character.xp + "<br><br><FONT COLOR=RED>Health: </FONT>" + 
        				Character.health + "<br><br><FONT COLOR=BLUE></FONT>" + Character.secondBar + ": </FONT>" + Use + 
        				"<br><br><br><br><br><br><br><br><br><br><br>" +
        				"Inventory<br>Ctrl+I<br><br>Character<br>Ctrl + C<br><br>Skills<br>Ctrl + S<br><br>Journal<br>Ctrl + J<br></html>");
                
                cstuff.add(CharFull);
                cstuff.add(SkillsFull);
                cstuff.add(JournalFull);
                cstuff.add(InvFull);
                
                menubar.add(cstuff);
        	}

        });
        
        dungeonButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent event) {
        		statusbar.setText("Into the abyss...");
        	}
        });
        
        shopButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent event) {
        		statusbar.setText("Time to spend that loot!");
        	}
        });
        
        JMenuItem Load = new JMenuItem("Load Game");
        Load.setToolTipText("Load a previously saved game");
        Load.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent event) {
        		statusbar.setText("Load feature in development");
        	}
        });
        
        JMenuItem Save = new JMenuItem("Save Game");
        Save.setToolTipText("Save your game from your current position");
        Save.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent event) {
        		statusbar.setText("Save feature has not been developed yet");
        	}
        });
        
        JMenuItem Background = new JMenuItem("Background Color");
        Background.setToolTipText("Change the background color of the game");
        Background.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent event) {
        		statusbar.setText("Choosing background color");
            	new JColorChooser();
                Color color = JColorChooser.showDialog(main, "Choose Color",
                        Color.white);
                main.setBackground(color);
                dungeonButton.setBackground(color);
        	}
        });
        
        
        help.add(Controls);
        
        settings.add(Vset);
        settings.add(Aset);
        settings.add(Gset);
        
        Vset.add(Background);
        
        game.add(New);
        game.add(Load);
        game.add(Save);
        game.addSeparator();
        game.add(Exit);
        
        
        menubar.add(game);
        menubar.add(settings);
        menubar.add(help);

        setJMenuBar(menubar);
        
        
        
        
        setTitle("Dungeon Crawler");
        setSize(1200, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);

    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                Example ex = new Example();
                ex.setVisible(true);
            }
        });
    }
}