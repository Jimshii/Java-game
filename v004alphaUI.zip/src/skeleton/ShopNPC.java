package skeleton;

public class ShopNPC {

	String response1 = "gtfo my face nigga"; 
	// Do like a dozen of these response.
	//String responsetitle = "what he actually says";
	//Name the response whatever you want so that they fit the actual response.
	//Make sure to include things like "Would you like to view my items?" or "You don't have enough money for that!"
	//Easter eggs gogogogogo
	//We can't do much more with NPCs until we figure out how we're going to do gameplay.
	//If you can think of anything else you want to add other than responses go ahead.

}
